<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Class WPBakeryShortCode_Vc_Gitem_Zone
 */
class WPBakeryShortCode_Vc_Gitem_Zone extends WPBakeryShortCodesContainer {
	public $zone_name = '';
}
