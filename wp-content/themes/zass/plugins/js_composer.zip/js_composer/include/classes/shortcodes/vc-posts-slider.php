<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Class WPBakeryShortCode_Vc_Posts_slider
 */
class WPBakeryShortCode_Vc_Posts_Slider extends WPBakeryShortCode {
}
